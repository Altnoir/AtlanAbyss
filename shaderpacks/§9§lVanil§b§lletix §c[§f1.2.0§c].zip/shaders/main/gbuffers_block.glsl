/*
================================ /// Super Duper Vanilla v1.3.6 /// ================================

    Developed by Eldeston, presented by FlameRender (C) Studios.

    Copyright (C) 2023 Eldeston | FlameRender (C) Studios License


    By downloading this content you have agreed to the license and its terms of use.

================================ /// Super Duper Vanilla v1.3.6 /// ================================
*/

/// Buffer features: TAA jittering, complex shading, End portal, PBR, and world curvature

/// -------------------------------- /// Vertex Shader /// -------------------------------- ///

#ifdef VERTEX
    
    flat out vec3 vertexColor;

    flat out mat3 TBN;

    out vec2 lmCoord;
    out vec2 texCoord;

    out vec3 vertexFeetPlayerPos;

    #if defined NORMAL_GENERATION || defined PARALLAX_OCCLUSION
        flat out vec2 vTexCoordScale;
        flat out vec2 vTexCoordPos;

        out vec2 vTexCoord;
    #endif

    uniform mat4 gbufferModelViewInverse;

    #ifdef WORLD_CURVATURE
        uniform mat4 gbufferModelView;
    #endif

    #if ANTI_ALIASING == 2
        uniform int frameMod;

        uniform float pixelWidth;
        uniform float pixelHeight;

        #include "/lib/utility/taaJitter.glsl"
    #endif

    attribute vec4 at_tangent;

    #if defined NORMAL_GENERATION || defined PARALLAX_OCCLUSION
        attribute vec2 mc_midTexCoord;
    #endif

    void main(){
        texCoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
        vertexColor = gl_Color.rgb;

        #ifdef WORLD_CUSTOM_SKYLIGHT
            lmCoord = vec2(min(gl_MultiTexCoord1.x * 0.00416667, 1.0), WORLD_CUSTOM_SKYLIGHT);
        #else
            lmCoord = min(gl_MultiTexCoord1.xy * 0.00416667, vec2(1));
        #endif

        vec3 vertexNormal = fastNormalize(gl_Normal);
        vec3 vertexTangent = fastNormalize(at_tangent.xyz);

        vec3 vertexViewPos = mat3(gl_ModelViewMatrix) * gl_Vertex.xyz + gl_ModelViewMatrix[3].xyz;
        vertexFeetPlayerPos = mat3(gbufferModelViewInverse) * vertexViewPos + gbufferModelViewInverse[3].xyz;

        TBN = mat3(gbufferModelViewInverse) * (gl_NormalMatrix * mat3(vertexTangent, cross(vertexTangent, vertexNormal) * sign(at_tangent.w), vertexNormal));

        #if defined NORMAL_GENERATION || defined PARALLAX_OCCLUSION
            vec2 midCoord = (gl_TextureMatrix[0] * vec4(mc_midTexCoord, 0, 0)).xy;
            vec2 texMinMidCoord = texCoord - midCoord;

            vTexCoordScale = abs(texMinMidCoord) * 2.0;
            vTexCoordPos = min(texCoord, midCoord - texMinMidCoord);
            vTexCoord = sign(texMinMidCoord) * 0.5 + 0.5;
        #endif

        #ifdef WORLD_CURVATURE
            vertexFeetPlayerPos.y -= dot(vertexFeetPlayerPos.xz, vertexFeetPlayerPos.xz) * worldCurvatureInv;
            vertexViewPos = mat3(gbufferModelView) * vertexFeetPlayerPos + gbufferModelView[3].xyz;
        #endif

        gl_Position.xyz = getMatScale(mat3(gl_ProjectionMatrix)) * vertexViewPos;
        gl_Position.z += gl_ProjectionMatrix[3].z;
        gl_Position.w = -vertexViewPos.z;

        #if ANTI_ALIASING == 2
            gl_Position.xy += jitterPos(gl_Position.w);
        #endif
    }
#endif

/// -------------------------------- /// Fragment Shader /// -------------------------------- ///

#ifdef FRAGMENT
    /* RENDERTARGETS: 0,1,2,3 */
    layout(location = 0) out vec4 sceneColOut; // gcolor
    layout(location = 1) out vec3 normalDataOut; // colortex1
    layout(location = 2) out vec3 albedoDataOut; // colortex2
    layout(location = 3) out vec3 materialDataOut; // colortex3

    flat in vec3 vertexColor;
    flat in mat3 TBN;

    in vec2 lmCoord;
    in vec2 texCoord;
    in vec3 vertexFeetPlayerPos;

    #if defined NORMAL_GENERATION || defined PARALLAX_OCCLUSION
        flat in vec2 vTexCoordScale;
        flat in vec2 vTexCoordPos;
        in vec2 vTexCoord;
    #endif

    uniform int blockEntityId;

    uniform int isEyeInWater;

    uniform float nightVision;
    uniform float pixelWidth;
    uniform float pixelHeight;
    uniform float fragmentFrameTime;

    uniform sampler2D tex;
    uniform sampler2D lightmap;

    #ifdef IS_IRIS
        uniform float lightningFlash;
    #endif

    #ifndef FORCE_DISABLE_WEATHER
        uniform float rainStrength;
    #endif

    #if defined SHADOW_FILTER && ANTI_ALIASING >= 2
        uniform float frameFract;
    #endif

    #ifndef FORCE_DISABLE_DAY_CYCLE
        uniform float dayCycle;
        uniform float twilightPhase;
    #endif

    #ifdef WORLD_VANILLA_FOG_COLOR
        uniform vec3 fogColor;
    #endif

    #ifdef WORLD_CUSTOM_SKYLIGHT
        const float eyeBrightFact = WORLD_CUSTOM_SKYLIGHT;
    #else
        uniform float eyeSkylight;
        float eyeBrightFact = eyeSkylight;
    #endif

    #ifdef WORLD_LIGHT
        uniform float shdFade;
        uniform mat4 shadowModelView;

        #ifdef SHADOW_MAPPING
            uniform mat4 shadowProjection;
            #include "/lib/lighting/shdMapping.glsl"
        #endif

        #include "/lib/lighting/GGX.glsl"
    #endif

    #include "/lib/PBR/dataStructs.glsl"

    #if PBR_MODE <= 1
        #include "/lib/PBR/integratedPBR.glsl"
    #else
        #include "/lib/PBR/labPBR.glsl"
    #endif

    #include "/lib/utility/noiseFunctions.glsl"

    #include "/lib/lighting/complexShadingForward.glsl"

    void main(){
        if(blockEntityId == 12000){
            vec2 screenPos = gl_FragCoord.xy * vec2(pixelWidth, pixelHeight);
            float starSpeedBase = fragmentFrameTime * 0.0025;

            float aspectRatio = pixelWidth / pixelHeight;
            vec2 aspectCorrectedPos = (screenPos - vec2(0.5)) * vec2(1.0, aspectRatio) + vec2(0.5);

            float rotationAngle = fragmentFrameTime * 0.05;
            mat2 rotationMatrix = mat2(
                cos(rotationAngle), -sin(rotationAngle),
                sin(rotationAngle),  cos(rotationAngle)
            );

            vec2 rotatedScreenPos = rotationMatrix * (aspectCorrectedPos - vec2(0.5)) + vec2(0.5);

            float distanceFromCenter = length(rotatedScreenPos - vec2(0.5));
            float radialStretchFactor = 1.0 + (distanceFromCenter * 2.0);
            vec2 stretchedScreenPos = (rotatedScreenPos - vec2(0.5)) * radialStretchFactor + vec2(0.5);

            float starSpeed1 = starSpeedBase * 1.0;
            float starSpeed2 = starSpeedBase * 4.0;
            float starSpeed3 = starSpeedBase * 0.5;
            float starSpeed4 = starSpeedBase * 2.5;
            float starSpeed5 = starSpeedBase * 3.5;

            float endStarField1 = textureLod(tex, vec2(stretchedScreenPos.y,  stretchedScreenPos.x + starSpeed1) * 0.5, 0).r;
            float endStarField2 = textureLod(tex, vec2(stretchedScreenPos.x,  stretchedScreenPos.y + starSpeed2),       0).r;
            float endStarField3 = textureLod(tex, vec2(-stretchedScreenPos.x, starSpeed3 - stretchedScreenPos.y) * 2.0, 0).r;
            float endStarField4 = textureLod(tex, vec2(-stretchedScreenPos.x, starSpeed4 - stretchedScreenPos.y) * 2.5, 0).r;
            float endStarField5 = textureLod(tex, vec2(-stretchedScreenPos.x, starSpeed5 - stretchedScreenPos.y) * 8.0, 0).r;

            vec2 endStarCoord1  = vec2(stretchedScreenPos.x - stretchedScreenPos.y,
                                       stretchedScreenPos.y + stretchedScreenPos.x);
            float endStarField6 = textureLod(tex, vec2( endStarCoord1.y, endStarCoord1.x + starSpeed1 * 1.2) * 0.5, 0).r;
            float endStarField7 = textureLod(tex, vec2( endStarCoord1.x, endStarCoord1.y + starSpeed2 * 1.2),       0).r;
            float endStarField8 = textureLod(tex, vec2(-endStarCoord1.x, starSpeed3 * 2.0 - endStarCoord1.y) * 2.0, 0).r;

            vec3 color1 = vec3(1.0, 0.4, 0.8); vec3 color2 = vec3(0.8, 0.4, 1.0);
            vec3 color3 = vec3(0.4, 0.8, 1.0); vec3 color4 = vec3(1.0, 0.6, 0.8);
            vec3 color5 = vec3(0.6, 0.4, 1.0); vec3 color6 = vec3(0.4, 1.0, 0.8);
            vec3 color7 = vec3(1.0, 0.8, 0.4); vec3 color8 = vec3(0.8, 0.4, 0.6);

            vec3 layerColor1 = mix(color1, color2, sin(fragmentFrameTime * 0.4) * 0.5 + 0.5);
            vec3 layerColor2 = mix(color3, color4, sin(fragmentFrameTime * 0.8) * 0.5 + 0.5);
            vec3 layerColor3 = mix(color5, color6, sin(fragmentFrameTime * 1.2) * 0.5 + 0.5);
            vec3 layerColor4 = mix(color7, color8, sin(fragmentFrameTime * 1.6) * 0.5 + 0.5);
            vec3 layerColor5 = mix(color1, color3, sin(fragmentFrameTime * 2.0) * 0.5 + 0.5);
            vec3 layerColor6 = mix(color2, color4, sin(fragmentFrameTime * 2.4) * 0.5 + 0.5);
            vec3 layerColor7 = mix(color5, color7, sin(fragmentFrameTime * 2.8) * 0.5 + 0.5);
            vec3 layerColor8 = mix(color6, color8, sin(fragmentFrameTime * 3.2) * 0.5 + 0.5);

            vec3 finalColor = (endStarField1 * layerColor1) + (endStarField2 * layerColor2) +
                              (endStarField3 * layerColor3) + (endStarField4 * layerColor4) +
                              (endStarField5 * layerColor5) + (endStarField6 * layerColor6) +
                              (endStarField7 * layerColor7) + (endStarField8 * layerColor8);

            finalColor *= 0.05;
            sceneColOut = vec4(toLinear(finalColor * EMISSIVE_INTENSITY * EMISSIVE_INTENSITY * 2.0), 1);
            normalDataOut = TBN[2];
            materialDataOut = vec3(0);
            return;
        }

        dataPBR material;
        getPBR(material, blockEntityId);

        material.albedo.rgb = toLinear(material.albedo.rgb);

        // Pass blockEntityId explicitly — complexShadingForward no longer relies on a free variable
        sceneColOut = vec4(complexShadingForward(material, blockEntityId), material.albedo.a);

        normalDataOut = material.normal;
        albedoDataOut = material.albedo.rgb;
        materialDataOut = vec3(material.metallic, material.smoothness, 0);
    }
#endif
