// Fragment GL version
#version 330 compatibility

#define GBUFFERS
#define BLOCK
#define FRAGMENT

#include "/lib/settings.glsl"
#include "/lib/utility/common.glsl"

#include "world.glsl"
#include "/main/moving_block.glsl"