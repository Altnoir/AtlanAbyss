// Vertex GL version
#version 330 compatibility

#define COMPOSITE2
#define VERTEX

#include "/lib/settings.glsl"
#include "/lib/utility/common.glsl"

#include "world.glsl"
#include "/main/composite2.glsl"