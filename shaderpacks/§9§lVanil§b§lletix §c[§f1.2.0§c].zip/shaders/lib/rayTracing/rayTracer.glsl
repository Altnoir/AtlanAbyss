vec3 rayTraceScene(in vec3 screenPos, in vec3 viewPos, in vec3 rayDir, in float dither){
    if(rayDir.z > -viewPos.z) return vec3(0);

    vec3 screenPosRayDir = fastNormalize(
        getScreenPos(gbufferProjection, viewPos + rayDir) - screenPos
    ) * rayTracerStepsInv;

    vec3 startPos = screenPos + screenPosRayDir * dither;

    for(int i = 0; i < RAYTRACER_STEPS; i++){
        startPos += screenPosRayDir;

        if(startPos.x < 0.0 || startPos.y < 0.0 ||
           startPos.x > 1.0 || startPos.y > 1.0) return vec3(0);

        float currDepth = textureLod(depthtex0, startPos.xy, 0).x;

        if(currDepth <= 0.56) return vec3(0);

        bool intersection = currDepth < startPos.z;

        if(intersection){
            #if RAYTRACER_BISTEPS != 0
                for(int j = 0; j < RAYTRACER_BISTEPS; j++){
                    if(currDepth == 1.0) return vec3(0);

                    screenPosRayDir *= 0.5;
                    startPos += intersection ? -screenPosRayDir : screenPosRayDir;

                    currDepth   = textureLod(depthtex0, startPos.xy, 0).x;
                    intersection = currDepth < startPos.z;
                }
            #else
                if(currDepth == 1.0) return vec3(0);
            #endif


            // smooth transition at all four screen borders
            const float EDGE_WIDTH = 0.35;
            vec2 edgeFade = smoothstep(0.0, EDGE_WIDTH, startPos.xy) * smoothstep(1.0, 1.0 - EDGE_WIDTH, startPos.xy);
            float fade = edgeFade.x * edgeFade.y;
            const float stepsInv = 1.0 / float(RAYTRACER_STEPS);
            fade *= 1.0 - smoothstep(0.6, 1.0, float(i) * stepsInv);

            // Return hit UV + blend
            return vec3(startPos.xy, fade);
        }
    }

    return vec3(0);
}