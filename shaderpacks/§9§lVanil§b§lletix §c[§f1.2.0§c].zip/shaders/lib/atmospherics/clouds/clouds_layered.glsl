#if defined STORY_MODE_CLOUDS && !defined FORCE_DISABLE_CLOUDS

int cloudParallax(in vec2 start, in float time){
        vec2 end = start * 0.005;
        start.x += time;

        int cloudData = 0;
        for(int i = 1; i <= 24; i++){
            if(texelFetch(colortex4, ivec2(start) & 255, 0).x < 0.5) cloudData = i;
            start -= end;
        }
        return cloudData;
    }

vec3 cloudParallaxDynamic(in vec2 start, in float time){
        vec2 end = start * 0.005;
        start.x += time * .5;

        vec2 cloudData = vec2(0);
        for(int i = 1; i <= 24; i++){
            vec2 cloudMap = texelFetch(colortex4, ivec2(start) & 255, 0).xy;
            if(cloudMap.x < 0.5) cloudData.x = i;
            if(cloudMap.y < 0.5) cloudData.y = i;
            start -= end;
        }

        return vec3(cloudData/4, maxOf(cloudData));
    }

vec3 renderClouds(in vec3 nEyePlayerPos, in vec3 currSkyCol, in float rainStrength, in float fragmentFrameTime) {
     float cloudHeightFade = 1.0 - (nEyePlayerPos.y - 0.125);

    #ifdef FORCE_DISABLE_WEATHER
        cloudHeightFade *= 5.0;
    #else
        cloudHeightFade -= rainStrength * 0.01;
        cloudHeightFade *= 5.0 - rainStrength * 0.4;
    #endif

    if (cloudHeightFade < 0.005) return currSkyCol;

    float cloudTime = fragmentFrameTime * 0.125;
    vec2 planeUv = nEyePlayerPos.xz * (6.0 / nEyePlayerPos.y);

    #ifdef DYNAMIC_CLOUDS
        float fadeTime = saturate(sin(fragmentFrameTime * FADE_SPEED) * 1.8 + 0.5);

        vec3 cloudData0 = cloudParallaxDynamic(planeUv, cloudTime);
        float clouds = mix(mix(cloudData0.x, cloudData0.y, fadeTime), cloudData0.z, rainStrength) * min(cloudHeightFade, 1.0) * 0.025;

        #ifdef DOUBLE_LAYERED_CLOUDS
            vec3 cloudData1 = cloudParallaxDynamic(-planeUv * 0.5, -cloudTime * 0.1);
            clouds += mix(mix(cloudData1.x, cloudData1.y, fadeTime), cloudData1.z, rainStrength) * (1.0 - clouds) * cloudHeightFade * 0.025;
        #endif
    #else
        float clouds = cloudParallax(planeUv, cloudTime * 0.5) * min(cloudHeightFade, 1.0) * 0.025;

        #ifdef DOUBLE_LAYERED_CLOUDS
            clouds += cloudParallax(-planeUv * 4.0, -cloudTime * 0.5) * (1.0 - clouds) * cloudHeightFade * 0.025;
        #endif
    #endif

    #ifdef FORCE_DISABLE_DAY_CYCLE
        currSkyCol += lightCol * clouds;
    #else
        vec3 cloudColor = mix(moonCol, sunCol, dayCycleAdjust);
        currSkyCol += cloudColor * clouds;
    #endif

    return currSkyCol;
}

#endif