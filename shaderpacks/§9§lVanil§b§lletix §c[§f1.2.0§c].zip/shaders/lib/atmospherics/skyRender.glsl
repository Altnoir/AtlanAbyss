#ifdef WORLD_AETHER
#endif

// Round sun and moon
float getSunMoonShape(in float skyPosZ){
    return min(1.0, exp2((WORLD_SUN_MOON_SIZE - sqrt(1.0 - skyPosZ * skyPosZ)) * 256.0));
}

// Default sun and moon
float getSunMoonShape(in vec2 skyPos){
    return min(1.0, exp2((WORLD_SUN_MOON_SIZE - pow(abs(skyPos.x * skyPos.x * skyPos.x) + abs(skyPos.y * skyPos.y * skyPos.y), 0.33333333)) * 256.0));
}

#if CLOUDS_STYLE == 0
    #include "clouds/clouds_layered.glsl"
#elif CLOUDS_STYLE == 1
    #include "clouds/clouds_one_layered.glsl"
#else
    #include "clouds/clouds_volumetric.glsl"

#endif


vec3 enhanceColor(in vec3 color) {
    float luminance = dot(color, vec3(0.02126, 0.07152, 0.00722));
    vec3 saturatedColor = mix(vec3(luminance), color, 1.5);
    return saturatedColor * vec3(1.1, 1.0, 0.9);
}

vec3 getSkyBasic(in float nEyePlayerPosY, in float skyPosZ){
    vec3 currSkyCol = skyCol + toLinear(AMBIENT_LIGHTING + nightVision * 0.5);
    currSkyCol = enhanceColor(currSkyCol);

    #ifdef WORLD_SKY_GROUND
        if(nEyePlayerPosY < 0 && isEyeInWater == 0) currSkyCol *= exp2(-(nEyePlayerPosY * nEyePlayerPosY * 8.0) / max(skyCol * skyCol, vec3(0.125)));
    #endif

    #if defined WORLD_LIGHT && WORLD_SUN_MOON == 1
        #ifdef FORCE_DISABLE_DAY_CYCLE
            if(skyPosZ > 0) currSkyCol += lightCol * pow(skyPosZ * skyPosZ, abs(nEyePlayerPosY) + 1.0);
        #else
            float lightDiffuse = pow(skyPosZ * skyPosZ, abs(nEyePlayerPosY) + 1.0);
            float diffuseCycleAdjust = dayCycleAdjust * lightDiffuse;
            currSkyCol += skyPosZ > 0 ? sunCol * diffuseCycleAdjust : moonCol * (lightDiffuse - diffuseCycleAdjust);
        #endif
    #endif

    #ifdef IS_IRIS
        currSkyCol += lightningFlash;
    #endif

    
    
    return currSkyCol;
}

vec3 getSkyHalf(in vec3 nEyePlayerPos, in vec3 skyPos, in vec3 currSkyCol){
    #if (defined WORLD_AETHER && defined WORLD_LIGHT) || defined WORLD_STARS
        vec2 skyCoordScale = skyPos.xy * 256.0;
    #endif

    #if defined WORLD_AETHER && defined WORLD_LIGHT
        int aetherAnimationSpeed = int(fragmentFrameTime * 8.0);
        ivec2 aetherTexelCoord0 = ivec2(255 - skyCoordScale - aetherAnimationSpeed) & 255;
        ivec2 aetherTexelCoord1 = ivec2(aetherTexelCoord0.x, int(skyCoordScale.y - aetherAnimationSpeed) & 255);
        ivec2 aetherTexelCoord2 = ivec2(int(skyCoordScale.x - aetherAnimationSpeed) & 255, aetherTexelCoord0.y);

        vec3 aetherNoise = vec3(texelFetch(noisetex, aetherTexelCoord0, 0).z,
            texelFetch(noisetex, aetherTexelCoord1, 0).z,
            texelFetch(noisetex, aetherTexelCoord2, 0).z);

        currSkyCol += exp2(-abs(nEyePlayerPos.y) * 8.0) * cubed(aetherNoise * lightCol + sumOf(aetherNoise) * 0.66666666) * lightCol * 5;
    #endif

    #ifdef WORLD_STARS
        vec2 starData = texelFetch(noisetex, ivec2(skyCoordScale / (abs(skyPos.z) + sqrt(1.0 - skyPos.z * skyPos.z))) & 255, 0).xy;
        float stars = exp(starData.x * starData.y * 64.0 - 64.0);

        #ifdef FORCE_DISABLE_WEATHER
            currSkyCol += stars * WORLD_STARS;
        #else
            currSkyCol += (1.0 - rainStrength) * stars * WORLD_STARS;
        #endif
    #endif

    #if defined STORY_MODE_CLOUDS && defined WORLD_LIGHT && !defined FORCE_DISABLE_CLOUDS
        currSkyCol = renderClouds(nEyePlayerPos, currSkyCol, rainStrength, fragmentFrameTime);
    #endif

    return currSkyCol;
}

vec3 getSkyFogRender(in vec3 nEyePlayerPos){
    if(isEyeInWater == 1) return vec3(0);
    if(isEyeInWater == 2) return fogColor;

    vec3 skyPos = mat3(shadowModelView) * nEyePlayerPos;

    #if defined WORLD_LIGHT && !defined FORCE_DISABLE_DAY_CYCLE
        if(dayCycle < 1) skyPos.xz = -skyPos.xz;
    #endif

    vec3 currSkyCol = getSkyBasic(nEyePlayerPos.y, skyPos.z);
    
    #if defined WORLD_AETHER && defined WORLD_LIGHT
        vec2 skyCoordScale = skyPos.xy * 256.0;
        int aetherAnimationSpeed = int(fragmentFrameTime * 8.0);

        ivec2 aetherTexelCoord0 = ivec2(255 - skyCoordScale - aetherAnimationSpeed) & 255;
        ivec2 aetherTexelCoord1 = ivec2(aetherTexelCoord0.x, int(skyCoordScale.y - aetherAnimationSpeed) & 255);
        ivec2 aetherTexelCoord2 = ivec2(int(skyCoordScale.x - aetherAnimationSpeed) & 255, aetherTexelCoord0.y);

        vec3 aetherNoise = vec3(texelFetch(noisetex, aetherTexelCoord0, 0).z,
            texelFetch(noisetex, aetherTexelCoord1, 0).z,
            texelFetch(noisetex, aetherTexelCoord2, 0).z);

        currSkyCol += exp2(-abs(nEyePlayerPos.y) * 8.0) * cubed(aetherNoise * lightCol + sumOf(aetherNoise) * 0.66666666) * lightCol;
    #endif

    return currSkyCol * saturate(nEyePlayerPos.y + eyeBrightFact * 3.0 - 1.0);
}

vec3 getSkyFogRender(in vec3 nEyePlayerPos, in vec3 skyPos, in vec3 currSkyCol){
    if(isEyeInWater == 1) return vec3(0);
    if(isEyeInWater == 2) return fogColor;

    #if defined WORLD_AETHER && defined WORLD_LIGHT
        vec2 skyCoordScale = skyPos.xy * 256.0;
        int aetherAnimationSpeed = int(fragmentFrameTime * 8.0);

        ivec2 aetherTexelCoord0 = ivec2(255 - skyCoordScale - aetherAnimationSpeed) & 255;
        ivec2 aetherTexelCoord1 = ivec2(aetherTexelCoord0.x, int(skyCoordScale.y - aetherAnimationSpeed) & 255);
        ivec2 aetherTexelCoord2 = ivec2(int(skyCoordScale.x - aetherAnimationSpeed) & 255, aetherTexelCoord0.y);

        vec3 aetherNoise = vec3(texelFetch(noisetex, aetherTexelCoord0, 0).z,
            texelFetch(noisetex, aetherTexelCoord1, 0).z,
            texelFetch(noisetex, aetherTexelCoord2, 0).z);

        currSkyCol += exp2(-abs(nEyePlayerPos.y) * 8.0) * cubed(aetherNoise * lightCol + sumOf(aetherNoise) * 0.66666666) * lightCol;
    #endif

    return currSkyCol * saturate(nEyePlayerPos.y + eyeBrightFact * 3.0 - 1.0);
}

vec3 getSkyReflection(in vec3 reflectViewDir){
    if(isEyeInWater == 2) return fogColor;

    vec3 reflectPlayerDir = mat3(gbufferModelViewInverse) * reflectViewDir;
    vec3 skyPos = mat3(shadowModelView) * reflectPlayerDir;

    #if defined WORLD_LIGHT && !defined FORCE_DISABLE_DAY_CYCLE
        if(dayCycle < 1) skyPos.xz = -skyPos.xz;
    #endif

    vec3 finalCol = getSkyBasic(reflectPlayerDir.y, skyPos.z);
    
    // Reflection-specific sky additions (Aether, Stars) - CLOUDS intentionally skipped by default
    #if (defined WORLD_AETHER && defined WORLD_LIGHT) || defined WORLD_STARS
        vec2 skyCoordScale = skyPos.xy * 256.0;
    #endif

    #if defined WORLD_AETHER && defined WORLD_LIGHT
        int aetherAnimationSpeed = int(fragmentFrameTime * 8.0);
        ivec2 aetherTexelCoord0 = ivec2(255 - skyCoordScale - aetherAnimationSpeed) & 255;
        ivec2 aetherTexelCoord1 = ivec2(aetherTexelCoord0.x, int(skyCoordScale.y - aetherAnimationSpeed) & 255);
        ivec2 aetherTexelCoord2 = ivec2(int(skyCoordScale.x - aetherAnimationSpeed) & 255, aetherTexelCoord0.y);

        vec3 aetherNoise = vec3(texelFetch(noisetex, aetherTexelCoord0, 0).z,
            texelFetch(noisetex, aetherTexelCoord1, 0).z,
            texelFetch(noisetex, aetherTexelCoord2, 0).z);

        finalCol += exp2(-abs(reflectPlayerDir.y) * 8.0) * cubed(aetherNoise * lightCol + sumOf(aetherNoise) * 0.66666666) * lightCol * 5;
    #endif

    #ifdef WORLD_STARS
        vec2 starData = texelFetch(noisetex, ivec2(skyCoordScale / (abs(skyPos.z) + sqrt(1.0 - skyPos.z * skyPos.z))) & 255, 0).xy;
        float stars = exp(starData.x * starData.y * 64.0 - 64.0);

        #ifdef FORCE_DISABLE_WEATHER
            finalCol += stars * WORLD_STARS;
        #else
            finalCol += (1.0 - rainStrength) * stars * WORLD_STARS;
        #endif
    #endif

    // Clouds in reflections
    #if defined STORY_MODE_CLOUDS && defined WORLD_LIGHT && !defined FORCE_DISABLE_CLOUDS
    #ifdef CLOUDS_IN_REFLECTIONS 
        finalCol = renderClouds(reflectPlayerDir, finalCol, rainStrength, fragmentFrameTime);
    #endif
#endif

    if(isEyeInWater == 1) return finalCol * max(0.0, reflectPlayerDir.y + eyeBrightFact - 1.0);

    #ifdef WORLD_LIGHT
        const float fakeVLBrightness = VOLUMETRIC_LIGHTING_STRENGTH * 0.5;
        float VLBrightness = fakeVLBrightness * shdFade;

        if(reflectPlayerDir.y > 0){
            float heightFade = squared(squared(squared(1.0 - squared(reflectPlayerDir.y))));

            #ifndef FORCE_DISABLE_WEATHER
                heightFade += (1.0 - heightFade) * rainStrength * 0.5;
            #endif

            VLBrightness *= heightFade;
        }
        
        finalCol += lightCol * VLBrightness;
    #endif

    return finalCol * saturate(reflectPlayerDir.y + eyeBrightFact * 3.0 - 1.0);
}

vec3 getFullSkyRender(in vec3 nEyePlayerPos, in vec3 skyPos, in vec3 currSkyCol){
    if(isEyeInWater == 2) return fogColor;

    #ifdef WORLD_LIGHT
        #if WORLD_SUN_MOON == 1 && SUN_MOON_TYPE != 2
            #if SUN_MOON_TYPE == 1
                float sunMoonShape = getSunMoonShape(skyPos.z) * sunMoonIntensitySqrd;
            #else
                float sunMoonShape = getSunMoonShape(skyPos.xy) * sunMoonIntensitySqrd;
            #endif

            #ifndef FORCE_DISABLE_WEATHER
                #ifdef FORCE_DISABLE_DAY_CYCLE
                    currSkyCol += sRGBLightCol * (sunMoonShape - rainStrength * sunMoonShape);
                #else
                    currSkyCol += (skyPos.z > 0 ? sRGBSunCol : sRGBMoonCol) * (sunMoonShape - rainStrength * sunMoonShape);
                #endif
            #endif
        #elif WORLD_SUN_MOON == 2
            // Black hole parameters
            const float blackHoleSize = 1024.0 - WORLD_SUN_MOON_SIZE * 8.0;
            float blackHole = blackHoleSize - skyPos.z * 1024.0;

            if (blackHole <= 0.0) return vec3(0.0);

            blackHole = 1.0 / max(1.0, blackHole);

            const float rotationFactor = TAU * 5.0;
            skyPos.xy = rot2D(blackHole * rotationFactor) * skyPos.xy;

            float ringSpeed = 4.0;
            float ringDensity = 16.0;
            float ringThickness = 0.1;
            float ringFalloff = 0.5;

            float ringDistance = fract(skyPos.z * ringDensity - fragmentFrameTime * ringSpeed * 0.1);

            vec2 noiseUV = skyPos.xy * 0.1 + fragmentFrameTime * 0.01;
            float noise = textureLod(noisetex, noiseUV, 0).x;
            ringDistance += (noise - 0.5) * 0.2;

            float ring = smoothstep(ringThickness - ringFalloff, ringThickness + ringFalloff, ringDistance);

            vec3 ringColor = mix(vec3(0.0), vec3(1.0, 1.0, 1.0), ringDistance);
            ringColor *= smoothstep(0.9, 0.5, ringDistance);

            currSkyCol += ring * ringColor * blackHole * sunMoonIntensitySqrd * lightCol;

            // Star-shaped hole effect
            float starPoints = 9.0;
            float starSharpness = 0.01;
            float starTime = -fragmentFrameTime * 0.05;

            // Convert to polar coordinates
            float angle = atan(skyPos.y, skyPos.x);
            float radius = length(skyPos.xy);

            // Create star shape using trigonometric functions
            float star = cos(angle * starPoints + starTime) ;
            star = smoothstep(starSharpness, 1.0, star);

            // Apply star shape as a cutout (hole)
            float starHole = smoothstep(0.3, 0.4, radius * (4 * sin(0.1 * fragmentFrameTime) - star * 0.25));
            currSkyCol *= starHole;

            float glow = smoothstep(0.0, 0.5, blackHole) * 10;
            currSkyCol += glow * vec3(0.4, 0.3, 0.6) * (1.0 - starHole);
        #endif
    #endif

    currSkyCol = getSkyHalf(nEyePlayerPos, skyPos, currSkyCol);

    if(isEyeInWater == 1) return currSkyCol * saturate(nEyePlayerPos.y * 1.66666667 - 0.16666667);
    return currSkyCol * saturate(nEyePlayerPos.y + eyeBrightFact * 3.0 - 1.0);
}