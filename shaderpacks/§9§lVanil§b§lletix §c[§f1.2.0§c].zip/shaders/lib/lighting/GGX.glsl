float getNoHSquared(in float NoL, in float NoV, in float VoL) {
  const float radiusCos = inversesqrt(1.0 + WORLD_SUN_MOON_SIZE * WORLD_SUN_MOON_SIZE);
  const float radiusCosScale = radiusCos * WORLD_SUN_MOON_SIZE;

  float NoLNoV = 2.0 * NoL * NoV;
  float RoL = NoLNoV - VoL;
  if (RoL >= radiusCos)
    return 1.0;

  float NoVSqrd = NoV * NoV;
  float rOverLengthT = inversesqrt(1.0 - RoL * RoL) * radiusCosScale;

  float NoTr = rOverLengthT * (NoV - RoL * NoL);
  float VoTr = rOverLengthT * (2.0 * NoVSqrd - 1.0 - RoL * VoL);

  float tripleDelta = 1.0 - NoL * NoL - NoVSqrd - VoL * VoL + NoLNoV * VoL;
  float tripleAlpha = max(0.0, rOverLengthT * sqrt(tripleDelta));

  float NoBr = tripleAlpha;
  float VoBr = 2.0 * tripleAlpha * NoV;

  float NoLVTr = NoL * radiusCos + NoV + NoTr;
  float VoLVTr = VoL * radiusCos + 1.0 + VoTr;

  float p = NoBr * VoLVTr;
  float q = NoLVTr * VoLVTr;
  float s = VoBr * NoLVTr;

  float xNum = q * (0.25 * s - 0.5 * p);
  float xDenom = p * p + s * (s - 2.0 * p) + NoLVTr * ((NoL * radiusCos + NoV) * VoLVTr * VoLVTr - q * (0.5 * (VoLVTr + VoL * radiusCos) + 0.5));

  float twoX1 = 2.0 * xNum / (xDenom * xDenom + xNum * xNum);
  float sinTheta = twoX1 * xDenom;
  float cosTheta = 1.0 - twoX1 * xNum;

  NoTr = cosTheta * NoTr + sinTheta * NoBr;
  VoTr = cosTheta * VoTr + sinTheta * VoBr;

  float newNoL = NoL * radiusCos + NoTr;
  float newVoL = VoL * radiusCos + VoTr;

  float NoH = NoV + newNoL;
  float HoH = 2.0 * newVoL + 2.0;

  return min(1.0, NoH * NoH / HoH);
}


// Improved Fast Specular BRDF
vec3 getSpecularBRDF(in vec3 V, in vec3 N, in vec3 albedo, in float NL, in float metallic, in float smoothness) {
    // Calculate the halfway vector
    vec3 lightDir = vec3(shadowModelView[0].z, shadowModelView[1].z, shadowModelView[2].z);
    vec3 H = fastNormalize(lightDir + V);
    
    // Dot products for lighting calculations
    float LH = dot(lightDir, H);
    
    // Roughness remapping for smoother reflections
    float roughness = 1.0 - smoothness;

    #if SPECULAR_HIGHLIGHTS == 0
      float alphaSqrd = roughness * roughness;
    #elif SPECULAR_HIGHLIGHTS == 1
      float alphaSqrd = roughness * roughness * smoothness;
    #elif SPECULAR_HIGHLIGHTS == 2
      float alphaSqrd = roughness * roughness * smoothness;
    #else
      float alphaSqrd = 0;
    #endif

    

    // Visibility term (Smith's shadowing function)
    float visibility = LH + (1.0 / roughness);
    
    // Scale specular intensity based on smoothness
    float specularMult = smoothness + 1.0;
    float specIntensity = sunMoonIntensitySqrd * specularMult;

    // Distribution using GGX or similar model
    float NHSqr = getNoHSquared(NL, dot(N, V), dot(V, lightDir));
    float denominator = squared(NHSqr * (alphaSqrd - 1.0) + 1.0);
    float distribution = (specularMult * alphaSqrd * NL) / (denominator * visibility * PI) * 2.55;

    // Rain occlusion handling
    #ifndef FORCE_DISABLE_WEATHER
        distribution *= 1.0 - rainStrength;
    #endif

    // Fresnel-Schlick approximation
    float cosTheta = exp2(-9.28 * LH);
    float oneMinusCosTheta = 1.0 - cosTheta;

    // Calculate the final specular color based on metallic and smoothness
    if (smoothness <= 0.9) {
        float basicFresnel = cosTheta + metallic * oneMinusCosTheta;
        return vec3(min(specIntensity, basicFresnel * distribution));
    }

    vec3 metallicFresnel = cosTheta + albedo * oneMinusCosTheta;
    return min(vec3(specIntensity * PI), metallicFresnel * distribution);
}
