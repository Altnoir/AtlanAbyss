vec3 getColorFromDirection(vec2 lightDir) {
  // // Getting color depending on direction
  float red = 0.5 + 1 * normalize(lightDir).x;
  float green = 0.5 + 0.5 * normalize(lightDir).y * 0.5;
  float blue = 0.5 - abs(normalize(lightDir).x) * 0.5;

  return vec3(red, green, blue) * vec3(LENS_FLARE_STRENGTH * sRGBLightCol);
  // return vec3(LENS_FLARE_STRENGTH * sRGBLightCol);
  // return vec3(LENS_FLARE_STRENGTH);
}

float lensShape(in vec2 lensCoord) {

  return length(lensCoord) - cubed(WORLD_SUN_MOON_SIZE);

}


vec2 rotateVec(vec2 v, float angle) {
    float s = sin(angle);
    float c = cos(angle);
    return vec2(
        c*v.x - s*v.y, 
        s*v.x + c*v.y
    );
}


// ----- LEGACY ----- //

float BaseLens(in vec2 centerCoord, in vec2 lightDir, in float size, in float dist, in float hardness) {
    vec2 flareCoord = centerCoord + lightDir * dist;
    vec2 lensCoord = vec2(flareCoord.x * aspectRatio, flareCoord.y);
    float lens = clamp(1.0 - length(lensCoord) / (size * shdLightDirScreenSpace.z), 0.0, 1.0 / hardness) * hardness;
    return squared(squared(lens)); // Apply smooth falloff
}

float lensFlareSimple(in vec2 centerCoord, in vec2 lightDir, in float size, in float dist) {
    return BaseLens(centerCoord, lightDir, size, dist, 1.0);
}

float lensFlareRays(in vec2 centerCoord, in vec2 lightDir, in float rayBeam, in float size, in float dist) {
  vec2 flareCoord = centerCoord + lightDir * dist;
  float rays = max(0.0, sin(atan(flareCoord.x * aspectRatio, flareCoord.y) * rayBeam));
  float lens = lensFlareSimple(centerCoord, lightDir, size, dist);
  return rays * lens + lens;
}


float PointLens(in vec2 centerCoord, in vec2 lightDir, in float size, in float dist) {
    float lens = BaseLens(centerCoord, lightDir, size, dist, 1.5) +
                 BaseLens(centerCoord, lightDir, size * 4.0, dist, 1.0) * 0.5;
    return lens * (0.5 + 0.5); // Adjust brightness based on sun factor
}

vec3 chromaLens(in vec2 centerCoord, in vec2 lightDir, in float chromaDist, in float size, in float dist) {
  return vec3(
    lensFlareSimple(centerCoord, lightDir, size, dist),
    lensFlareSimple(centerCoord, lightDir, size, dist * (1.0 - chromaDist)),
    lensFlareSimple(centerCoord, lightDir, size, dist * (1.0 - chromaDist * 2.0))
  );
}

float OverlapLens(in vec2 centerCoord, in vec2 lightDir, in float size, in float distA, in float distB) {
  float lensA = lensFlareSimple(centerCoord, lightDir, size, distA);
  float lensB = lensFlareSimple(centerCoord, lightDir, size, distB);
  return lensA * lensB; // Multiply the two lenses for an overlapping effect
}

float getPowerFromLightDirection(vec2 lightDir) {
  float power = (0.5 - max(max(lightDir.x, -lightDir.x), max(lightDir.y, -lightDir.y)));
  return smoothstep(0.0, 1.0, clamp(power, 0.0, 1.0)) * 5.0;
}

// Halo testing //

float ringLensTransform(in float lensFlare) {
  return pow(1.0 - pow(1.0 - pow(lensFlare, 0.25), 10.0), 5.0);
}

float ringLens(in vec2 centerCoord, in vec2 lightDir, in float size, in float distA, in float distB) {
  float lensFlare1 = ringLensTransform(lensFlareSimple(centerCoord, lightDir, size, distA));
  float lensFlare2 = ringLensTransform(lensFlareSimple(centerCoord, lightDir, size, distB));

  float lensFlare = clamp(lensFlare2 - lensFlare1, 0.0, 1.0);
  lensFlare *= sqrt(lensFlare);

  lensFlare *= 1.0 - length(texCoord - (centerCoord + lightDir * distB) - 0.5);
  return lensFlare;
}

// -- //

#if LENS_FLARE == 0
vec3 getLensFlare(in vec2 centerCoord, in vec2 lightDir) {
    // Base lenses (replacing lensFlareSimple)
    float baseLens0 = BaseLens(centerCoord, lightDir, 0.3, -0.45, 1.0);
    float baseLens1 = BaseLens(centerCoord, lightDir, 0.3, 0.10, 1.0);
    float baseLens2 = BaseLens(centerCoord, lightDir, 0.3, 0.30, 1.0);
    float baseLens3 = BaseLens(centerCoord, lightDir, 0.3, 0.50, 1.0);
    float baseLens4 = BaseLens(centerCoord, lightDir, 0.3, 0.70, 1.0);
    float baseLens5 = BaseLens(centerCoord, lightDir, 0.3, 0.90, 1.0);

    // Overlap lenses (for more complex effects)
    float overlapLens1 = OverlapLens(centerCoord, lightDir, 0.08, -0.28, -0.39);
    float overlapLens2 = OverlapLens(centerCoord, lightDir, 0.08, -0.20, -0.31);
    float overlapLens3 = OverlapLens(centerCoord, lightDir, 0.12, 0.06, 0.19);
    float overlapLens4 = OverlapLens(centerCoord, lightDir, 0.12, 0.15, 0.28);
    float overlapLens5 = OverlapLens(centerCoord, lightDir, 0.12, 0.24, 0.37);

    // Point lenses (for glowing points)
    float pointLens1 = PointLens(centerCoord, lightDir, 0.03, -0.55);
    float pointLens2 = PointLens(centerCoord, lightDir, 0.02, -0.40);
    float pointLens3 = PointLens(centerCoord, lightDir, 0.04, 0.43);
    float pointLens4 = PointLens(centerCoord, lightDir, 0.02, 0.60);
    float pointLens5 = PointLens(centerCoord, lightDir, 0.03, 0.67);

    // Chromatic aberration lenses
    vec3 chromaLens2 = chromaLens(centerCoord, lightDir, 0.1, 0.1, -0.3);
    vec3 chromaLens = chromaLens(centerCoord, lightDir, 0.07, 0.3, 0.7);

    // Ring lenses (for halo effects)
    vec3 ringLens1 = ringLens(centerCoord, lightDir, 0.22, 0.44, 0.46) * vec3(0.10, 0.35, 2.50) * 1.5;
    vec3 ringLens2 = ringLens(centerCoord, lightDir, 0.15, 0.98, 0.99) * vec3(0.15, 0.40, 2.55) * 2.5;

    // Combine all effects with colors
    vec3 flare = (
        // Base lenses with color variations
        baseLens0 * vec3(2.2, 1.2, 0.1) * 0.07 +
        baseLens1 * vec3(2.2, 0.4, 0.1) * 0.03 +
        baseLens2 * vec3(2.2, 0.2, 0.1) * 0.04 +
        baseLens3 * vec3(2.2, 0.4, 2.5) * 0.05 +
        baseLens4 * vec3(1.8, 0.4, 2.5) * 0.06 +
        baseLens5 * vec3(0.1, 0.2, 2.5) * 0.07 +

        // Overlap lenses with color variations
        overlapLens1 * vec3(2.5, 1.2, 0.1) * 0.015 +
        overlapLens2 * vec3(2.5, 0.5, 0.1) * 0.010 +
        overlapLens3 * vec3(2.5, 0.2, 0.1) * 0.020 +
        overlapLens4 * vec3(1.8, 0.1, 1.2) * 0.015 +
        overlapLens5 * vec3(1.0, 0.1, 2.5) * 0.010 +

        // Point lenses with color variations
        pointLens1 * vec3(2.5, 1.6, 0.0) * 0.06 +
        pointLens2 * vec3(2.5, 1.0, 0.0) * 0.045 +
        pointLens3 * vec3(2.5, 0.6, 0.6) * 0.06 +
        pointLens4 * vec3(0.2, 0.6, 2.5) * 0.045 +
        pointLens5 * vec3(0.7, 1.1, 3.0) * 0.075 +

        // Chromatic aberration effects
        chromaLens + chromaLens2 +

        // Ring lenses
        ringLens1 + ringLens2
    );

    // Add rays if applicable
    #if SUN_MOON_TYPE != 2
        float rays = lensFlareRays(centerCoord, lightDir, 8.0, 0.1, -1.0);
        flare += rays * vec3(1.0, 0.8, 0.6);
    // Final output for End World
        return flare_end * cubed(getPowerFromLightDirection(lightDir));
    #endif
    float rays = lensFlareRays(centerCoord, lightDir, 8.0, 1.0, -1.0);
    flare += rays * 0.5 * vec3(1.0, 0.8, 0.6);
    // Final output
    return flare * LENS_FLARE_STRENGTH * sRGBLightCol * getPowerFromLightDirection(lightDir);
}

// OFF (don't do like this, I mean never)
#elif LENS_FLARE == 1
vec3 getLensFlare(in vec2 centerCoord, in vec2 lightDir) {
    return vec3(0, 0, 0);
}
#endif

// Don't forget to add #endif unless that may break coposite6.glsl 🤦‍♂️