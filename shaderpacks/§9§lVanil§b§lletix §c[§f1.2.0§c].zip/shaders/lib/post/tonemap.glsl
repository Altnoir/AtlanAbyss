// /lib/post/tonemap.glsl
// Super Duper Vanilla's ACES upgrade


// Fallback defaults

#ifndef CONTRAST
    #define CONTRAST 1.0
#endif
#ifndef SATURATION
    #define SATURATION 1.0
#endif
#ifndef HIGHLIGHT_DESAT
    #define HIGHLIGHT_DESAT 0.4
#endif
#ifndef SHADOW_TOE
    #define SHADOW_TOE 0.08
#endif
#ifndef HUE_PRESERVATION
    #define HUE_PRESERVATION 0.85
#endif


// Shader Style Presets

#if SHADER_STYLE == 1
    #undef  CONTRAST
    #define CONTRAST         1.05 
    #undef  SATURATION
    #define SATURATION       0.95 
    #undef  HIGHLIGHT_DESAT
    #define HIGHLIGHT_DESAT  0.60 
    #undef  SHADOW_TOE
    #define SHADOW_TOE       0.12 
    #undef  HUE_PRESERVATION
    #define HUE_PRESERVATION 0.95 
#elif SHADER_STYLE == 2
    #undef  CONTRAST
    #define CONTRAST         1.20
    #undef  SATURATION
    #define SATURATION       1.20
    #undef  HIGHLIGHT_DESAT
    #define HIGHLIGHT_DESAT  0.20
    #undef  SHADOW_TOE
    #define SHADOW_TOE       0.05
    #undef  HUE_PRESERVATION
    #define HUE_PRESERVATION 0.70
#endif


// Rec.709 luminance

const vec3 LUMINANCE_COEFF = vec3(0.2126, 0.7152, 0.0722);

float getLuminance(vec3 col) {
    return dot(col, LUMINANCE_COEFF);
}


// ACES matrices (sRGB ↔ AP1)

const mat3 ACES_IN = mat3(
    0.59719, 0.07600, 0.02840,
    0.35458, 0.90834, 0.13383,
    0.04823, 0.01566, 0.83777
);

const mat3 ACES_OUT = mat3(
     1.60475, -0.10208, -0.00327,
    -0.53108,  1.10813, -0.07276,
    -0.07367, -0.00605,  1.07602
);

// RRT + ODT - fitted rational curve
vec3 acesRRTODT(vec3 v) {
    vec3 a = v * (v + 0.0245786) - 0.000090537;
    vec3 b = v * (0.983729 * v + 0.432951) + 0.238081;
    return a / b;
}

// Gamut compression 

vec3 gamutCompress(vec3 col) {
    float minComp = min(col.r, min(col.g, col.b));
    if (minComp >= 0.0) return col;

    float luma = max(dot(col, LUMINANCE_COEFF), 1e-6);
    float t    = minComp / (minComp - luma);
    return mix(col, vec3(luma), clamp(t * 0.85, 0.0, 1.0));
}


// Core tonemap - ACES with luminance-preserving chroma blend 

vec3 tonemap(vec3 color) {
    color = max(color, vec3(0.0));

    // Shadow toe - lift near-black (applied in linear sRGB)
    color += SHADOW_TOE * (1.0 - exp(-color * 10.0));

    vec3 ap1 = ACES_IN * color;
    ap1 = gamutCompress(ap1);

    // Per-channel ACES
    vec3 perChannel = acesRRTODT(ap1);

    // Luminance-only ACES
    float lumaIn = dot(ap1, LUMINANCE_COEFF);
    float lumaOut = acesRRTODT(vec3(lumaIn)).r;  
    lumaOut = max(lumaOut, 0.0);                  

    float lumaPerCh = dot(perChannel, LUMINANCE_COEFF);
    float scale = lumaOut / max(lumaPerCh, 1e-6); 
    vec3 chromaScaled = perChannel * scale;

    // Blend modes
    vec3 tonemapped = mix(perChannel, chromaScaled, HUE_PRESERVATION);
    tonemapped = clamp(tonemapped, 0.0, 1.0);

    tonemapped = ACES_OUT * tonemapped;
        tonemapped = clamp(tonemapped, 0.0, 1.0);

    // Highlight desaturation 
    if (HIGHLIGHT_DESAT > 0.0) {
        float luma = getLuminance(tonemapped);
        float t = smoothstep(0.7, 1.0, luma);
        tonemapped = mix(tonemapped, vec3(luma), HIGHLIGHT_DESAT * t);
    }

    return clamp(tonemapped, 0.0, 1.0); // Final safety clamp
}

#define modifiedReinhardExtended(c) tonemap(c)


// Contrast - rational sigmoid

vec3 contrast(vec3 col, float a) {
    col = clamp(col, 0.0, 1.0);
    vec3 x = col - 0.5;
    vec3 ax = x * a;
    return clamp(ax / (abs(ax) - abs(x) + 1.0) + 0.5, 0.0, 1.0);
}


// Saturation - perceptually weighted

vec3 saturation(vec3 col, float a) {
    float luma = getLuminance(col);
    float fade = smoothstep(0.05, 0.95, luma) * (1.0 - smoothstep(0.85, 1.0, luma));
    return mix(vec3(luma), col, mix(1.0, a, fade));
}