#if WATER_STYLE == 0
    const float PI2      = 6.28318530718;
    const float INV_256  = 1.0 / 256.0;
    const float GRID_RES = 256.0;

    vec2 cellSnap(vec2 uv) {
        return (floor(uv * GRID_RES) + 0.5) * INV_256;
    }

    float hash1(vec2 p) {
        return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
    }

    float hashAngle(vec2 p) {
        return hash1(p) * PI2;
    }

    float getSmoothAngle(vec2 uv, float gridSize) {
        vec2 grid  = uv * gridSize * 0.15;
        vec2 cell0 = floor(grid);
        vec2 cell1 = cell0 + 1.0;
        vec2 sf    = smoothstep(0.0, 1.0, fract(grid));

        float a00 = hashAngle(cell0);
        float a10 = hashAngle(vec2(cell1.x, cell0.y));
        float a01 = hashAngle(vec2(cell0.x, cell1.y));
        float a11 = hashAngle(cell1);

        vec2 d00 = vec2(cos(a00), sin(a00));
        vec2 d10 = vec2(cos(a10), sin(a10));
        vec2 d01 = vec2(cos(a01), sin(a01));
        vec2 d11 = vec2(cos(a11), sin(a11));

        vec2 finalDir = mix(mix(d00, d10, sf.x), mix(d01, d11, sf.x), sf.y);
        return atan(finalDir.y, finalDir.x);
    }

    vec2 warpUV(vec2 uv, float time) {
        vec2 warp = textureLod(noisetex, uv * 0.3 + time * 0.25, 0).xy;
        return uv + (warp - 0.5) * 0.15;
    }

    float getCellNoise(in vec2 uv) {
        vec2  pUV      = cellSnap(uv);
        float baseTime = fragmentFrameTime * CURRENT_SPEED * INV_256 * 2;
        vec2  baseUV   = warpUV(pUV, baseTime);

        float baseAngle = getSmoothAngle(baseUV, 4.0);
        vec2  baseDir   = vec2(cos(baseAngle), sin(baseAngle));
        vec2  crossDir  = vec2(-baseDir.y, baseDir.x);

        float ampMod = textureLod(noisetex, baseUV * 0.5, 0).x * 0.5 + 0.5;

        float wave1  = textureLod(noisetex, baseUV + baseDir  * baseTime * 1.0, 0).z;
        float wave2  = textureLod(noisetex, baseUV + crossDir * baseTime * 1.3, 0).z * 0.50;
        float ripple = textureLod(noisetex, baseUV * 4.0 + baseDir * baseTime * 2.0, 0).z * 0.25;

        return (wave1 + wave2 + ripple) * ampMod;
    }

    vec4 H2NWater(in vec2 uv) {
        vec2 sUV = cellSnap(uv);
        float ps = INV_256;
        float depthScale = WATER_BLUR_SIZE * WATER_DEPTH_SIZE;

        float hC  = getCellNoise(sUV);
        float hXp = getCellNoise(sUV + vec2( ps, 0.0));
        float hXn = getCellNoise(sUV - vec2( ps, 0.0));
        float hYp = getCellNoise(sUV + vec2(0.0,  ps));
        float hYn = getCellNoise(sUV - vec2(0.0,  ps));

        vec3 normal = normalize(vec3(
            (hXn - hXp) * 1.25,
            (hYn - hYp) * 1.25,
            depthScale
        ));

        vec2 cellID = floor(sUV * GRID_RES);
        float timeOffset = hash1(cellID * 0.13) * 10.0;
        float t = fragmentFrameTime * 1.5 + timeOffset;
        float phaseShift = hash1(cellID) * PI2;
        float wave = sin(t + phaseShift);
        
        float threshold = 0.95;
        float sparkleFactor = 0.0;
        
        if (wave > threshold) {
            sparkleFactor = smoothstep(threshold, 1.0, wave);
            sparkleFactor = pow(sparkleFactor, 2.0);
        }

        float tiltAngle = hash1(cellID * 1.7) * PI2;
        float tiltStr   = 0.15 * sparkleFactor;
        
        vec3  sparkleN  = normalize(vec3(
            cos(tiltAngle) * tiltStr,
            sin(tiltAngle) * tiltStr,
            1.0
        ));

        normal = normalize(mix(normal, sparkleN, sparkleFactor * 0.70));
        return vec4(normal, hC);
    }


#elif WATER_STYLE == 2
float getCellNoise(in vec2 uv) {
    const float currentSpeed = CURRENT_SPEED * 0.095;
    float animateTime = fragmentFrameTime * currentSpeed;
    return textureLod(noisetex, uv + animateTime, 0).z 
         + textureLod(noisetex, animateTime - uv, 0).z;
}


float getWaveLayer(vec2 uv, float time, float frequency, float speed, vec2 direction, float steepness) {
    float phase = dot(uv, direction) * frequency - time * speed;
    float wave = sin(phase) + sin(phase * 2.3 + 1.7) * 0.5; 
    return wave * steepness;
}


float getRealisticHeight(vec2 uv, float time) {

    vec2 windDir = normalize(vec2(WIND_SPEED, 0.001));
    float windSpeed = max(abs(WIND_SPEED), 0.01);
    float swell = getWaveLayer(uv, time, 0.8, 0.6 * windSpeed, windDir, 0.4);

    float mid = getWaveLayer(uv, time, 2.5, 1.2 * windSpeed, normalize(windDir + vec2(0.3, -0.2)), 0.25);

    vec2 crossDir = normalize(vec2(-windDir.y, windDir.x));
    float ripple = getWaveLayer(uv, time, 6.0, 2.0 * windSpeed, crossDir, 0.12);

    float turb = textureLod(noisetex, uv * 8.0 + time * 0.4, 0).z * 0.08;
    
    float ampMod = 1.0 + textureLod(noisetex, uv * 0.5, 0).x * 0.3;
    return (swell + mid + ripple + turb) * ampMod;
}

vec4 H2NWater(in vec2 uv) {
    const float waterPixel = WATER_BLUR_SIZE * 0.004;
    const float waterDepth = WATER_BLUR_SIZE * WATER_DEPTH_SIZE;
    
    float time = fragmentFrameTime * CURRENT_SPEED * 0.095;
    
    float hC  = getRealisticHeight(uv, time);
    float hXp = getRealisticHeight(vec2(uv.x + waterPixel, uv.y), time);
    float hXn = getRealisticHeight(vec2(uv.x - waterPixel, uv.y), time);
    float hYp = getRealisticHeight(vec2(uv.x, uv.y + waterPixel), time);
    float hYn = getRealisticHeight(vec2(uv.x, uv.y - waterPixel), time);
    
    vec3 normal = normalize(vec3(
        (hXn - hXp) * 0.5,
        (hYn - hYp) * 0.5,
        waterDepth        
    )
    );
    
    float foamHint = smoothstep(0.65, 0.95, hC);
    foamHint *= textureLod(noisetex, uv * 4.0 + time * 0.2, 0).x;
    
    return vec4(normal, foamHint);
}
#else
     float getCellNoise(in vec2 uv){
        const float currentSpeed = CURRENT_SPEED * 0.0625;
        float animateTime = fragmentFrameTime * currentSpeed;
        return textureLod(noisetex, uv + animateTime, 0).z + textureLod(noisetex, animateTime - uv, 0).z;
    }

    vec4 H2NWater(in vec2 uv){
        const float waterPixel = WATER_BLUR_SIZE * 0.00390625;
        const float waterDepth = WATER_BLUR_SIZE * WATER_DEPTH_SIZE;

        float d0 = getCellNoise(uv);
        float d1 = getCellNoise(vec2(uv.x + waterPixel, uv.y));
        float d2 = getCellNoise(vec2(uv.x, uv.y + waterPixel));
        
        return vec4(fastNormalize(vec3(d0 - d1, d0 - d2, waterDepth)), d0);
    }
#endif


